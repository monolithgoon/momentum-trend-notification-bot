
export const EODHD_LIVE_US_QUOTE_URL = "https://eodhd.com/api/real-time";
export const EODHD_WEBSOCKET_URL = "wss://ws.eodhistoricaldata.com/ws/us-quote?api_token=demo";
