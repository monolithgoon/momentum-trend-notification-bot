
export const KC_MULTIPLIER = 2;
export const TREND_WINDOW = 5;
export const VOLUME_LOOKBACK = 10;
export const VOLUME_SPIKE_MULTIPLIER = 2;
export const TREND_THRESHOLD = 3;
export const AGGREGATE_LOOKBACK_MINUTES = 15;
export const MAX_KC_TICKS = 300;
