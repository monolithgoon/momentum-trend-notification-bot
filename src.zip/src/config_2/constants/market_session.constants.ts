
export const MARKET_OPEN_UTC = 13 * 3600 + 30 * 60;
export const MARKET_CLOSE_UTC = 20 * 3600;
