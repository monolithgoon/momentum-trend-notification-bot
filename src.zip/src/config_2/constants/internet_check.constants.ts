export const DNS_CHECK_HOSTS = ["google.com", "cloudflare.com", "1.1.1.1"];
export const DEFAULT_INTERNET_TIMEOUT_MS = 3000;
