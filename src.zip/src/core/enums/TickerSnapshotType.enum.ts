export enum TickerSnapshotType {
  QUOTE = "QUOTE",
  HISTORICAL = "HISTORICAL"
}