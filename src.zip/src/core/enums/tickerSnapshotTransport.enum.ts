export enum TickerSnapshotTransport {
	REST = "REST",
	WEBSOCKET = "WEBSOCKET",
}
