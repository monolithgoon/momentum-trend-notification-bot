export enum MarketDataVendor {
	POLYGON = "polygon",
	FMP = "fmp",
	// EODHD = "eodhd",
	// IEX = "iex",
	// Add more vendors here as needed
}
