export enum MarketDataVendors {
	POLYGON = "polygon",
	// EODHD = "eodhd",
	// IEX = "iex",
	// Add more vendors here as needed
}
