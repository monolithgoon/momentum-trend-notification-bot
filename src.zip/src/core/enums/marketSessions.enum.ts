export enum MarketSessions {
	PRE_MARKET = "pre_market",
	RTH = "rth",
	AFTER_MARKET = "after_market",
}
