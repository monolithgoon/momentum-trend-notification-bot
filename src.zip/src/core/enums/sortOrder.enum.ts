export enum SortOrder {
  ASC = "asc",
  DESC = "desc"
}