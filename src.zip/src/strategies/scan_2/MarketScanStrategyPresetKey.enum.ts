export enum MarketScanStrategyPresetKey {
  MARKET_TOP_MOVERS = "Top market movers", // REMOVE
  MARKET_MOST_ACTIVE = "Top market active",
  MARKET_TOP_GAINERS = "Top market gainers",
  MARKET_TOP_LOSERS = "Top market losers",
  MARKET_TOP_RECENT_IPO = "Recent IPO Top Moving",
}
