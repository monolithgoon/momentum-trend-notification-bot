````mermaid
%% LeaderboardService Dependency Flow Graph with More Annotations (Private methods = bright yellow)

graph TD
  %% Main service class
  LeaderboardService["🏆 <b>LeaderboardService</b><br/>Manages leaderboard logic
  <br/>🏛️ Class | 🔒 private, 🟢 public
  <br/><i>Coordinates storage, scoring, ranking, and retrieval of leaderboard data</i>
  "]:::service

  %% Dependencies (external modules/interfaces)
  LeaderboardStorage["💾 LeaderboardStorage
  <br/>🏷️ Interface
  <br/><i>Persists & retrieves leaderboard and snapshots</i>
  "]:::storage

  scoringFn["🧮 leaderboardScoringFnType
  <br/>🏷️ Type
  <br/><i>Defines signature for scoring strategies</i>
  "]:::type

  scoringStrategies["🧰 scoringStrategies
  <br/>📦 Object
  <br/><i>Holds available scoring functions</i>
  "]:::util

  sorter["🔢 GenericTickerSorter
  <br/>🏷️ Interface
  <br/><i>Sorts leaderboard entries</i>
  "]:::sorter

  kinetics["⚡ percChangeKineticsCalculators
  <br/>📦 Object
  <br/><i>Calculates velocity and acceleration</i>
  "]:::util

  config["⚙️ APP_CONFIG
  <br/>📦 Object
  <br/><i>Global configuration</i>
  "]:::config

  LeaderboardSnapshotsMap["📄 LeaderboardSnapshotsMap
  <br/>🏷️ Type
  <br/><i>Batch of processed ticker data</i>
  "]:::type

  LeaderboardRestTickerSnapshot["📊 LeaderboardRestTickerSnapshot
  <br/>🏷️ Type
  <br/><i>Leaderboard entry structure</i>
  "]:::type

  %% Entrypoint
  processNewSnapshots["▶️ processNewSnapshots()
  <br/>🟢 public ⚡ async
  <br/>Input: 📄 LeaderboardSnapshotsMap, 🔢 GenericTickerSorter
  <br/>Output: 📊 Promise&lt;LeaderboardRestTickerSnapshot[]&gt;
  <br/>💾 persists, ⚠️ error logging
  <br/><i>Batch orchestrator: processes, ranks, persists, returns leaderboard</i>
  "]:::method

  %% Key internal/private methods (bright yellow)
  initializeLeaderboardIfMissing["🛠️ initializeLeaderboardIfMissing()
  <br/>🔒 private ⚡ async
  <br/>Input: string
  <br/>Output: void (Promise)
  <br/>💾 creates leaderboard store if missing
  <br/><i>Ensures store exists for tag</i>
  "]:::privatemethod

  storeNewSnapshots["💾 storeNewSnapshots()
  <br/>🔒 private ⚡ async
  <br/>Input: 📄 LeaderboardSnapshotsMap, string
  <br/>Output: void (Promise)
  <br/>💾 persists, ⚠️ error logging
  <br/><i>Stores each ticker snapshot in storage</i>
  "]:::privatemethod

  computeBatchKinetics["⚡ computeBatchKinetics()
  <br/>🔒 private ⚡ async
  <br/>Input: 📄 LeaderboardSnapshotsMap, string
  <br/>Output: Map&lt;string, 📊 LeaderboardRestTickerSnapshot&gt; (Promise)
  <br/>💾 reads, ⚠️ error logging
  <br/><i>Calculates velocity and acceleration for each ticker</i>
  "]:::privatemethod

  mergeWithPreviousLeaderboard["🔗 mergeWithPreviousLeaderboard()
  <br/>🔒 private ⚡ async
  <br/>Input: string, Map&lt;string, 📊 LeaderboardRestTickerSnapshot&gt;
  <br/>Output: Map&lt;string, 📊 LeaderboardRestTickerSnapshot&gt; (Promise)
  <br/>💾 reads, ⚠️ error logging
  <br/><i>Merges current and previous leaderboard states</i>
  "]:::privatemethod

  sortAndRankLeaderboard["🔢 sortAndRankLeaderboard()
  <br/>🔒 private
  <br/>Input: 📊 LeaderboardRestTickerSnapshot[], 🔢 GenericTickerSorter
  <br/>Output: 📊 LeaderboardRestTickerSnapshot[]
  <br/><i>Sorts and assigns rank numbers</i>
  "]:::privatemethod

  persistLeaderboard["💽 persistLeaderboard()
  <br/>🔒 private ⚡ async
  <br/>Input: string, 📊 LeaderboardRestTickerSnapshot[]
  <br/>Output: void (Promise)
  <br/>💾 persists, ⚠️ throws
  <br/><i>Saves leaderboard to storage</i>
  "]:::privatemethod

  retreiveLeaderboard["📬 retreiveLeaderboard()
  <br/>🟢 public ⚡ async
  <br/>Input: string
  <br/>Output: 📊 Promise&lt;LeaderboardRestTickerSnapshot[] | null&gt;
  <br/>💾 reads
  <br/><i>Retrieves leaderboard for a given tag</i>
  "]:::method

  %% Flow
  LeaderboardService --> processNewSnapshots
  processNewSnapshots --> initializeLeaderboardIfMissing
  processNewSnapshots --> storeNewSnapshots
  processNewSnapshots --> computeBatchKinetics
  processNewSnapshots --> mergeWithPreviousLeaderboard
  processNewSnapshots --> sortAndRankLeaderboard
  processNewSnapshots --> persistLeaderboard
  processNewSnapshots -->|returns| sortAndRankLeaderboard

  %% Scoring and sorting
  processNewSnapshots -.-> scoringFn
  processNewSnapshots -.-> sorter

  %% Storage interactions
  initializeLeaderboardIfMissing --> LeaderboardStorage
  storeNewSnapshots --> LeaderboardStorage
  computeBatchKinetics --> LeaderboardStorage
  mergeWithPreviousLeaderboard --> LeaderboardStorage
  persistLeaderboard --> LeaderboardStorage
  retreiveLeaderboard --> LeaderboardStorage

  %% Kinetics calculations
  computeBatchKinetics --> kinetics
  computeBatchKinetics --> config

  %% Sorting
  sortAndRankLeaderboard --> sorter

  %% Input/Output types
  processNewSnapshots -.-> LeaderboardSnapshotsMap
  sortAndRankLeaderboard -.-> LeaderboardRestTickerSnapshot

  %% API
  LeaderboardService --> retreiveLeaderboard

  %% Scoring strategies
  LeaderboardService -.-> scoringStrategies

  %% Styles
  classDef service fill:#f9f,stroke:#222,stroke-width:2px;
  classDef storage fill:#e3f9e5,stroke:#222,stroke-width:1.5px;
  classDef type fill:#f9f9e3,stroke:#222,stroke-width:1.5px;
  classDef util fill:#e3e7f9,stroke:#222,stroke-width:1.5px;
  classDef sorter fill:#e3e7f9,stroke:#222,stroke-width:1.5px;
  classDef config fill:#f9e3e3,stroke:#222,stroke-width:1.5px;
  classDef method fill:#fff,stroke:#666,stroke-width:1px;
  classDef privatemethod fill:#ffff33,stroke:#666,stroke-width:2px;
````
